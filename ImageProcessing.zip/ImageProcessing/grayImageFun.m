function [ output_args ] = grayImageFun( input_args )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    output_args = rgb2gray(input_args);
end

